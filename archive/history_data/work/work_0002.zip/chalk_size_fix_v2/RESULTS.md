# Chalk-size fix v2: segmented FFC pull (2026-10-01). Local only, do not commit (uses 2026 DK/FFC ownership).

**Question.** The broad v1 pull (FFC top-N toward raw FFC) helped 2 of 3 weeks but raided budget from true mega-chalk (bias30 worse). Does restricting the pull to FFC top-N players with an identifiable reason, and/or freezing shipped mega-chalk out of the re-allocation, give a clean win in every held-out week without worsening bias30?

**Data limit (checked).** FFC ownership files exist only for 2026 (`data/ownership_public/ffc_*`, wk1-4). So this can be tested only on 2026 wk1-3: 9 slates. History cannot settle it.

**Method.** The harness is identical to v1 (`test_seg.py` imports `chalk_size_fix/test_chalk.py`).
- Baseline: the same shipped model (blend a=.45 plus vac bump).
- Same N x b grid, picked leave-one-week-out on training-week MAE.
- Segment thresholds were fixed before looking at results:
  - vacated >= .15
  - salary < 5.5k
  - salary < 7k
  - FFC >= 1.5x shipped
- "Freeze" means rows shipped >= 25% keep their value and are left out of the group re-allocation.
- The last two rows (sal<5.5k + freeze variants) were added after seeing the first nine, so treat them as post-hoc.

## Held-out deltas vs shipped
Each cell is d corr(all) / d MAE(all) / d bias30(all) / d bias30($7k+) / d catch20(cheap WR/TE).

| segment | wk1 | wk2 | wk3 | pooled |
|---|---|---|---|---|
| broad (v1) | +.022 -.059 +0.5 +2.0 +.00 | +.007 -.033 -1.3 -1.8 +.12 | **-.008 +.039 -2.5 -5.5** +.27 | +.007 -.019 -1.1 -1.9 +.17 |
| vac>=.15 (role bump) | +.011 -.033 -0.3 0.0 0 | +.004 -.016 -0.5 -0.7 +.25 | **-.004 +.022** -0.4 -0.3 0 | +.003 -.009 -0.4 -0.4 +.08 |
| sal<5.5k | +.001 -.010 -0.2 -0.3 0 | +.007 -.023 -1.0 -1.2 +.12 | +.004 -.002 -0.0 **-1.1** +.27 | +.003 -.012 -0.4 -0.9 +.17 |
| sal<7k | +.004 -.012 0 -0.3 0 | -.002 -.001 -1.7 -2.5 +.12 | +.002 +.014 -0.4 +0.5 0 | +.001 .000 -0.7 -0.8 +.04 |
| FFC>=1.5x ship | +.013 -.041 +0.3 +1.4 0 | +.011 -.040 -0.1 +0.4 +.12 | **-.004 +.037 -1.3 -2.9** +.27 | +.007 -.015 -0.4 -0.4 +.17 |
| vac OR FFC>=1.5x | +.013 -.041 +0.3 +1.4 0 | +.012 -.041 -0.4 +0.1 +.12 | **-.003 +.027 -1.3 -2.8** +.27 | +.007 -.018 -0.5 -0.5 +.17 |
| broad + freeze | +.027 -.075 +1.5 +2.8 0 | +.003 -.018 -2.0 -2.6 +.12 | **-.014 +.081** -2.3 -3.4 +.18 | +.005 -.006 -0.9 -1.3 +.12 |
| vac + freeze | +.008 -.028 -0.4 -0.1 0 | +.004 -.015 0 0 +.25 | **-.006 +.024** -0.2 0 0 | +.002 -.007 -0.2 0 +.08 |
| FFC>=1.5x + freeze | +.011 -.043 +0.5 +0.5 0 | +.011 -.041 +2.0 +3.1 +.12 | **-.005 +.036** +0.6 0 +.27 | +.005 -.016 +1.0 +1.3 +.17 |
| sal<5.5k + freeze (post-hoc) | +.001 -.009 0 0 0 | +.004 -.018 -0.4 0 +.12 | .000 **+.005** +0.7 0 +.27 | +.001 -.007 +0.1 0 +.17 |
| sal<5.5k WR/TE + freeze (post-hoc) | +.001 -.009 0 0 0 | -.002 -.002 -0.4 0 +.12 | +.001 +.011 -0.6 0 +.09 | 0 0 -0.3 0 +.08 |

The full per-week, per-band tables (corr, MAE, catch20/15, bias20/30/10-30, top10) are in `test_seg_out.txt`.

## Verdict: no ship. Inconclusive, keep testing (one cell). Role-bump segmentation is wrong-direction: drop it.
- **Role-bump flag (vacated)** does not fix it. Wk3 still gets worse, and catch20 gains shrink. The role-bump mechanism is not what drives the cheap-chalk gain.
- **Freezing mega-chalk works mechanically.** $7k+ bias30 is unchanged in every week, so the budget raid is stopped. But wk3 still worsens whenever pricier players are pulled, which means FFC's ranking of mid-priced top-N is itself worse than ours in wk3.
- **Best cell: sal<5.5k (+ freeze).**
  - Pooled cheap WR/TE catch20 goes .58 to .75 and bias20 -8.1 to -5.8 to -6.0, with every week non-worse on catch20.
  - $7k+ bias30 stays at 0 change.
  - All-player corr is flat to up, and MAE is down in wk1 and wk2. Wk3 MAE is +.005, which is noise-level but not a clean win.
  - It was chosen post-hoc on the same 3 weeks.
  - The no-freeze version wins corr and MAE in all 3 weeks, but still costs $7k+ bias30 in every week (-0.3 / -1.2 / -1.1).

Nothing clears the ship bar. No change was made to `scripts/ownership_v2.py`.
