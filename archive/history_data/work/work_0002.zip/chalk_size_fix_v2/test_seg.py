"""Chalk-size fix v2: SEGMENTED FFC-pull. Same harness/metrics/LOWO as analysis/chalk_size_fix/test_chalk.py, but the
pull only hits FFC top-N players that ALSO carry an identifiable reason flag, and optionally freezes shipped mega-chalk
out of the budget re-allocation (so the pull cannot raid it). Segment thresholds are fixed a priori (not tuned);
only (N, b) are picked leave-one-week-out on training-week all-skill MAE. 2026 DK + FFC ownership only, no FC data."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "chalk_size_fix"))
import test_chalk as T  # noqa  (loads Y, ship, ffc, y, BANDS, m, top10, ov)
Y, ship, ffc, y, BANDS, ov = T.Y, T.ship, T.ffc, T.y, T.BANDS, T.ov
wk = Y.week.to_numpy()


def seg_pull(mask, n, b, protect=None):
    """FFC pull for FFC slate top-n restricted to `mask`; rows in `protect` are frozen (excluded from re-allocation)."""
    base = ship.copy()
    skill = Y.pos.isin(["QB", "RB", "WR", "TE"]).to_numpy()
    ok = np.isfinite(base) & skill
    if b == 0:
        return base
    top = np.zeros(len(base), bool)
    for _, ix in Y[ok].groupby("slate_id").indices.items():
        rows = np.where(ok)[0][ix]
        f = np.where(np.isfinite(ffc[rows]), ffc[rows], -1.0)
        r = rows[np.argsort(-f, kind="stable")[:n]]
        top[r[ffc[r] > 0]] = True
    hit = top & mask
    frz = np.zeros(len(base), bool) if protect is None else (protect & ~hit)
    lb = np.log(np.maximum(np.where(ok, base, 0.0), .05))
    sc = np.where(hit, (1 - b) * lb + b * np.log(np.maximum(np.nan_to_num(ffc), .05)), lb)
    al = ok & ~frz
    sub = Y[al]
    out = base.copy()
    for (sid, g), ix in sub.groupby([sub.slate_id, sub.grp]).indices.items():
        rows = np.where(al)[0][ix]
        grp_all = ok & (Y.slate_id.to_numpy() == sid) & (Y.grp.to_numpy() == g)
        if not hit[rows].any():
            continue
        bud = base[grp_all].sum() - base[grp_all & frz].sum()
        out[rows] = ov.allocate(Y.iloc[rows], sc[rows], {g: float(bud)}, cap=ov.CAP)
    return out


vac = Y.vacated.fillna(0).to_numpy()
sal = Y.salary.to_numpy()
gap = np.nan_to_num(ffc) >= 1.5 * np.nan_to_num(ship)
mega = np.nan_to_num(ship) >= 25
ALL = np.ones(len(Y), bool)
SEGS = {
    "broad (v1)": (ALL, None),
    "vac>=.15": (vac >= .15, None),
    "sal<5.5k": (sal < 5500, None),
    "sal<7k": (sal < 7000, None),
    "ffc>=1.5x ship": (gap, None),
    "vac>=.15 OR ffc>=1.5x": ((vac >= .15) | gap, None),
    "broad + freeze ship>=25": (ALL, mega),
    "vac>=.15 + freeze": (vac >= .15, mega),
    "ffc>=1.5x + freeze": (gap, mega),
    # added AFTER seeing the first 9 rows (post-hoc; treat as hypothesis, not held-out evidence)
    "sal<5.5k + freeze": (sal < 5500, mega),
    "sal<5.5k WR/TE + freeze": ((sal < 5500) & Y.pos.isin(["WR", "TE"]).to_numpy(), mega),
}
NS, BS = T.NS, T.BS
KEYS = ["corr", "mae", "catch20", "catch15", "bias20", "bias30", "bias10_30"]
if __name__ == "__main__":
    pd.set_option("display.width", 250)
    summary, per_week = [], []
    for name, (mask, prot) in SEGS.items():
        cache = {(n, b): seg_pull(mask, n, b, prot) for n in NS for b in BS}
        held, chosen = np.full(len(Y), np.nan), {}
        for w in (1, 2, 3):
            tr = (wk != w) & BANDS["all"]
            best = min(cache, key=lambda k: (np.abs(np.nan_to_num(cache[k][tr]) - y[tr]).mean(), k[1]))
            chosen[w] = best; held[wk == w] = cache[best][wk == w]
        print(f"{name}: LOWO picks {chosen}")
        for w in (1, 2, 3, "all"):
            wm = (wk == w) if w != "all" else ALL
            for bn, bm in BANDS.items():
                for mdl, p in (("shipped", ship), (name, held)):
                    r = T.m(p, bm & wm); r.update(seg=name, model=mdl, week=w, band=bn)
                    if bn == "all":
                        r["top10"] = T.top10(p, bm & wm)
                    per_week.append(r)
    D = pd.DataFrame(per_week).drop_duplicates(["model", "week", "band"])
    D = D[["week", "band", "model"] + KEYS + ["top10"]].round(3)
    print(D.sort_values(["band", "week", "model"]).to_string(index=False))
    # verdict helper: held-out week wins vs shipped on all-band corr & MAE, and bias30 non-worse in all and $7k+
    print("\nVERDICT GRID (per held-out week: d_corr_all, d_mae_all, d_bias30_all, d_bias30_7k, d_catch20_cheap)")
    S = D.set_index(["model", "week", "band"])
    for name in SEGS:
        row = []
        for w in (1, 2, 3, "all"):
            a, s = S.loc[(name, w)], S.loc[("shipped", w)]
            row.append(f"w{w}: {a.loc['all','corr']-s.loc['all','corr']:+.3f} {a.loc['all','mae']-s.loc['all','mae']:+.3f} "
                       f"{a.loc['all','bias30']-s.loc['all','bias30']:+.1f} {a.loc['7k+','bias30']-s.loc['7k+','bias30']:+.1f} "
                       f"{a.loc['cheapWRTE','catch20']-s.loc['cheapWRTE','catch20']:+.2f}")
        print(f"{name:26s} | " + " | ".join(row))
