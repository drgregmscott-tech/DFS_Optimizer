# Early-season blend refit with props ON (local only, FC-derived, do not commit)

> **UPDATE (all-weeks history test, sections 5-6) overrides the wk1-3 read below.** Over 2021-25, all weeks, on
> current-code projections, the "cheap players under-weight salary" result does NOT hold: pulling cheap (<5k) players toward
> the salary line is worse in 4/5 seasons. The only consistent effect is expensive (6.5k+) skill players being
> OVER-projected in history, and 2026 has the opposite sign. Nothing ships.

Premise tested (owner's words): "Early-season blend refit with props ON (props exist only for 2026, so Wk1-3 only; thin, say so)."
Plus the lineup_replay guess: "props already carry the salary signal, so the blend double-counts."

Scripts: `run.py` (-> `run_out.txt`), `skill_lowo.py` (-> `skill_lowo_out.txt`). Frame = lineup_replay leak-free OLD rebuilds
(no blend, no QB recal) for all 9 DK classic 2026 slates, QB/RB/WR/TE, unique players per week, proj >= 3 or salary >= 4k,
actuals from `data/results_raw_dk_2026_wk*`. n = 206 / 236 / 220 (wk1/2/3).

## 1. The guess is wrong - and the premise's setup is wrong too

- **The wk1-2 rebuilds had no props.** `data/props` holds classic props for wk3 only (plus two showdowns). Props coverage in
  the frame: wk1 0%, wk2 0%, wk3 95%. So "blend worse because props are on" cannot explain wk1-2. The blend got worse on
  projections with NO props.
- **Where the damage actually came from: the QB weights.** Current blend vs no blend, player MAE:

| week | QB no blend | QB current blend | SKILL no blend | SKILL current blend |
|---|---|---|---|---|
| 1 | 6.76 | 7.46 | 5.54 | 5.56 |
| 2 | 5.68 | 6.86 (bias +0.4 -> +3.1) | 4.71 | 4.73 |

  The wk1 QB weight w=1.0 replaces the QB projection with the salary line; wk2 QB a=+2.74 inflates every QB ~3 pts.
- **Why weights fit on history fail on 2026:** the history parquet's own 2026 wk1 harness projection is much worse than the
  current-code rebuild (QB MAE 7.50 vs 6.76), and on that old harness the blend still helps 2026 (QB 7.50->7.18, SKILL
  5.48->5.08). So the blend was correcting weaknesses of the old harness projection that current code has already fixed.
  The weights are fit to a projection we no longer ship. Not props.
- **Props do NOT carry the salary signal.** On wk3 props-matched SKILL players (n=183), the residual (actual - proj) still
  rises with (salary line - proj): slope +0.60 (se 0.31). Held-out blend on those props-matched players: MAE 4.88 -> 4.75.
  The market-informed projection still under-weights price for skill players.

## 2. Refit on 2026 (thin: 3 weeks, one season, ~200 SKILL rows/week; leave-one-week-out, ridge toward 0)

SKILL only (QB excluded - QB w comes out negative, n~30/week, noise):

| held-out week | fit (a, w), lam=300 | MAE no blend -> refit | bias | top-40 projected, mean actual |
|---|---|---|---|---|
| wk1 | -0.37, +0.52 | 5.54 -> 5.43 | -0.06 -> -0.47 | 16.87 -> 17.04 |
| wk2 | -0.02, +0.22 | 4.71 -> 4.64 | +1.41 -> +1.33 | 14.00 -> 14.00 |
| wk3 (props on) | -0.37, +0.34 | 4.79 -> 4.69 | +0.25 -> -0.29 | 15.28 -> 15.75 |

3 of 3 held-out weeks better, -0.07 to -0.11 MAE (lam=100: -0.08 to -0.13). All-3-week fit, lam=300: a=-0.30, w=+0.38.
Caveat: the weeks are not independent seasons. This is one season's worth of evidence.

## 3. By position / tier / props coverage
- QB: blend hurts every week. Drop it (QB recal already owns QBs from wk3).
- SKILL gain is almost all **cheap (<5k)** players: wk1 4.42->4.18, wk3 4.46->4.32. 5-6.5k is flat. 6.5k+ is **hurt** in wk1
  (10.10->10.72), flat later. A tier-restricted rule (cheap/mid only) is the obvious next variant.
- Props coverage does not remove the effect (section 1). Unmatched n=11 is too small to say anything.

## 4. Historical proxy (FC projection as a market-informed base, LOSO 2021-25, 2026 held out)
Blend fit on top of FC projections instead of our harness:
- SKILL: helps in 4/4 held-out seasons at wk1, wk2 **and wk3** (wk1 5.41->4.76, wk2 5.36->5.13, wk3 5.43->4.99); 2026
  held out: wk1 5.71->5.32, wk2 4.95->4.56. Fitted w 0.6-0.74.
- QB: mixed / worse at wk1.
So even a commercial market-informed projection leaves a skill-player salary signal on the table. Proxy only: FC is not our
props-anchored projection. But it supports the 2026 read: "market info in the projection" does not absorb price.
On our old harness, by contrast, wk3 SKILL w was ~0.09 (no signal). Our current build behaves more like FC than like the
harness here.

## Recommendation
- Current blend (history weights): **wrong-direction - drop.** Keep `weeks={}` as is. Mainly the QB terms.
- QB salary blend at any week: **wrong-direction - drop.**
- SKILL-only salary pull (a~-0.3, w~+0.4) on current-code projections: **inconclusive - keep testing.** 3/3 held-out weeks
  better, props-on week included, FC proxy agrees, but it is one season. Not shipping. No candidate config written.
- Value for Sunday (Wk4): the old blend only touches wk1-2, so none. The live question for Wk4 is different: the SKILL
  signal showed up at wk3 with props on, so it may exist every week - that is a projection-level miss, not an early-season one.

## Single most valuable fixable thing
Our current skill projections (props on) under-weight salary, mostly for cheap WR/RB/TE: held-out a SKILL-only pull toward
the salary line cuts MAE 0.07-0.11 in each of wk1/wk2/wk3 2026 (wk3 props-matched 4.88->4.75), and the same pull on FC
projections helps in 4/4 history seasons. Next test (track 2): rebuild 2021-25 with CURRENT code for wk3-8 (lineup_replay's
hist rebuilds can supply frames) and fit a SKILL-only, tier-limited (<6.5k) (a, w) LOSO. If it holds there, wire it as
`_apply_early_season_blend` with config `weeks={"1+": {"SKILL": {...}}}` plus a tier cap, QB absent, off-switch
`--no-early-blend`, audit col `early_blend_delta` (all already exist; only a salary cap would be new code).


## 5. All-weeks history test (owner pushback: do the key test now)

Frame: `data/fc_history/derived/ourproj/proj_{season}_wk{week}.csv` = our statline engine re-run leak-free on every FC
main slate, regenerated 2026-09-26 (post projection-stack, pre blend / pre QB recal, props off since none exist
historically). All weeks 1-18 for 2021/22/23/25; 2024 has wk5-18 only. RB/WR/TE, played, proj >= 3 or salary >= 4k.
n = 4186 / 4219 / 4219 / 3309 / 4377 (2021-25). Second held-out: 2026 wk1-2 (ourproj) + wk3 (lineup_replay rebuild, props on),
n = 641. Fit final = E + a + w*(S - E), S = live config salary line, ridge 30, leave-one-season-out (LOSO). Script
`allweeks.py` -> `allweeks_out.txt`, `studs.py` -> `studs_out.txt`, weights `allweeks_weights.json`.

LOSO summary (MAE change vs no blend, n-weighted, 2021-25; negative = better):

| variant | dMAE | seasons better | top-24 projected, mean actual change | 2026 dMAE |
|---|---|---|---|---|
| global (a=+0.06, w=+0.34) | -0.016 | 4/5 | +0.11 | -0.086 |
| by week bucket (wk1-4 w=0.54, wk5-18 w=0.26) | -0.017 | 4/5 | +0.01 | -0.074 |
| by tier | -0.010 | 4/5 | -0.06 | -0.044 |
| tier x week bucket | -0.012 | 4/5 | -0.06 | -0.025 |
| RB vs WR/TE x tier | -0.015 | 4/5 | -0.04 | -0.060 |
| cheap only (<5k) | **+0.016** | **1/5** | 0.00 | -0.025 |

All gains are about 0.01-0.02 points per player, well below anything that changes a lineup. Top-24 ranking does not move.

Where it comes from (per-cell dMAE by season, RB vs WR/TE x tier):
- **6.5k+ WR/TE: better every season** (-0.13 to -0.25; 2026 -0.14). **6.5k+ RB: better 4/5** (-0.15 to -0.23).
- **Cheap (<5k) WR/TE: worse 4/5 seasons** (+0.006 to +0.10); only 2026 improves (-0.09). Cheap RB: mixed.
- 5-6.5k WR/TE: better 4/5; 5-6.5k RB: flat.

## 6. The expensive-player effect is a level problem, not a salary-weight problem

Pull fit only on 6.5k+ (a=-0.90, w=+0.52): MAE better in 5/5 seasons (8.03->7.87, 8.16->7.97, 7.87->7.68, 7.56->7.46,
7.94->7.72). But:
- It mostly LOWERS players (about 80% of them). Our history projections over-project 6.5k+ skill players: bias +0.3, +0.5,
  +1.5, +0.6, +1.3 by season. The pull is removing that bias.
- Top-24 projected points do not change (17.58->17.61, 17.80->17.64, ...). It fixes level, not ranking.
- **2026 wk1-3 is the other way.** Our 6.5k+ players are UNDER-projected (bias -0.77). The same pull pushes that to -2.4
  and MAE barely moves (9.02->8.96). This matches the wk2 postmortem stud under-projection.

So the stud level error flips sign between the history harness and the 2026 live build. A fixed salary pull cannot be
right for both.

## Final labels (supersede the section-2/3 read)
- Early blend, current weights: **wrong-direction, drop** (keep `weeks={}`).
- QB salary blend: **wrong-direction, drop.**
- Cheap WR/TE / cheap skill salary pull (the owner's cheap-WR/TE idea, applied to projections): **wrong-direction, drop.**
  History says our cheap-player projections are not short on salary signal. The 2026 wk1-3 gain was one small sample.
  Cheap WR/TE matters for ownership, where it is already handled (teammate-OUT bump and cheap WR/TE work in ownership_v2).
  It does not add true-points accuracy.
- All-weeks skill pull (any structure): **inconclusive, keep testing** (-0.01 to -0.02 MAE, no ranking gain). Not worth
  shipping. No candidate config written.
- Sunday (Wk4): nothing from this ships.

## Single most valuable fixable thing (revised)
The level of expensive (6.5k+) RB/WR/TE projections is off, in opposite directions in two places:
- History harness: over by +0.3 to +1.5 in every season.
- 2026 live build: under by -0.8.

Fixing the level in history is worth -0.10 to -0.19 MAE on those players, 5/5 seasons held out. But the 2026 sign flip
means the live build differs from the harness for studs, and that difference has to be found first. Otherwise any stud
calibration fit on history makes 2026 worse (held-out 2026 bias -0.77 -> -2.44).

Where the 2026 under-projection sits (section-1 frame, 6.5k+, bias = projection minus actual): wk1 -3.7 (n=24),
wk2 +1.3, wk3 -0.05. It is a week-1 effect. Wk1-2 had no props, so props are not the cause. Candidates are the wk1 rebuild's
`--season 2025 --week 23` data convention, or thin prior-season usage at season start. It is also only 24 players in one
week.

Next concrete step (track 2, matters for 2027 wk1, not Wk4):
1. Compare the 2026 wk1 studs' `engine_projection` vs `final_projection` (stack) with the 2025 wk1 studs from ourproj.
2. Check whether the wk23 convention drops the stud level.
3. Meanwhile, for wk2+ nothing here beats doing nothing by a margin worth shipping.
