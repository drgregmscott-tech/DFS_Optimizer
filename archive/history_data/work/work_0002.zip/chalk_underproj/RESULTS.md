# Chalk under-projection test (2026-09-30). DO NOT COMMIT (FC-derived)

**Premise tested (owner's words):** "our projections under-rate chalk the field gets right." In other words, do players with
high REAL field ownership score more than we project? If so, by how much, where, does it hold held-out and in 2026, and
how does FC compare on the same players?

Data: `data/fc_history/derived/model_vs_fc/frame.parquet`, the existing model_vs_fc frame. It has 86 FC single-entry main
slates from 2021-25 plus 2026 wk1-2 prod.
- Chalk means real own >= 15%: n = 1,244 history rows and 25 rows in 2026.
- CIs are slate-clustered bootstrap 95% intervals.
- History "ours" is the handicapped rebuild, with no injury news or props. 2026 is the real pre-lock file.
- 2026 wk3 is not included because the frame has no wk3 FC/actual join.
- Scripts: `a.py` (bias tables), `b.py` (LOSO corrections), `c.py` (teammate-absence split).

## Answer: yes, the premise is real. FC does not have this bias, and a simple pre-lock correction does not fix it.

Bias is act minus proj (positive means under-projected):

| real own | hist n | act-OURS | act-FC | 2026 n | act-OURS | act-FC |
|---|---|---|---|---|---|---|
| <5% | 42,539 | -1.03 [-1.11,-0.95] | -0.08 | 617 | +0.84 | -0.27 |
| 5-10% | 2,383 | +0.61 [+0.29,+0.93] | -0.80 | 45 | +5.06 | +1.25 |
| 10-20% | 1,674 | +0.84 [+0.43,+1.27] | -0.93 | 52 | +4.42 | -0.53 |
| 20-30% | 474 | +1.33 [+0.36,+2.33] | -0.80 | 7 | +7.3 | -1.4 |
| 30%+ | 223 | **+2.87 [+1.57,+4.19]** | +0.59 | 5 | +0.2 | -6.3 |

- **The bias grows with ownership.** It shows up in all 5 seasons (+0.6 to +2.2 on chalk) and is larger in 2026 prod.
  FC is roughly unbiased or slightly high on the same players.
- **Chalk by position (history, act-OURS):**
  - QB +3.6 [+1.7,+5.4]
  - RB +1.9 [+0.9,+3.0]
  - TE +1.8
  - WR +1.2
  - DST -1.3, the opposite direction
- **Chalk by price (history):**
  - 4.5-5.5k +3.8 [+2.5,+5.2], the worst band
  - <4.5k +1.8
  - 5.5-7k +1.8
  - 7k+ -0.6, not biased. This is not a stud problem on history.
  - In 2026, 7k+ chalk was +4.7, but n = 8.
- **The whole gap sits where we were below FC.**
  - Chalk with ours < FC - 2 (n = 600): act-OURS **+3.0** [+2.2,+3.8], act-FC -2.1.
  - Chalk with ours >= FC - 2 (n = 644): +0.1, unbiased.
  - The field and FC saw something our number missed.
- **About half of it is teammate absence.**
  - Chalk with a teammate absent (n = 309): +2.7.
  - Chalk without a teammate absent (n = 836): +1.3.
  - Measured with the `n_absent` flag in `frame_with_absence.parquet`.

## Held-out correction attempts (LOSO by season, residual model per position, pre-lock features only)
| correction | hist all dMAE | hist chalk dMAE | 2026 all | 2026 chalk |
|---|---|---|---|---|
| + our ownership estimate | -0.35 | **+0.17 (worse)** | -0.02 | +0.13 |
| + salary | -0.33 | +0.06 | -0.10 | +0.22 |
| + both | -0.32 | +0.16 | -0.08 | 0.00 |

- The overall MAE gains come from pulling down over-projected low-owned scrubs. That is a history-rebuild artifact, since
  the rebuild has no injury zeroing.
- **None of these fix chalk.** Chalk bias stays at about +2.3 after correction.
- Our ownership model only flags 23% of real history chalk (ours_own >= 12). On history features it cannot see what the
  field saw.

## Label
- **Premise: confirmed, real gap.** It holds across all 5 seasons and in 2026.
- **A generic chalk/ownership/salary bump: wrong-direction, drop.** It hurts chalk MAE held-out.
- **Targeted fix: inconclusive, keep testing.** No held-out win is shown yet.

## Single most valuable fixable thing (candidate only, not wired)
The under-projection is **role change we don't price in: vacated volume when a teammate is out**, plus a QB gap.

- **Teammate-absence reallocation for WR/TE (and QB target-share effects).** The RB version already shipped (8ca1ebc,
  who-replaces-whom).
  - Where: `scripts/` who-replaces-whom module. Extend the same function that reallocates OUT/DOUBTFUL RB share by depth
    rank so it also covers WR/TE target share.
  - Params: share of vacated targets to the next WR/TE by depth rank. Fit it on history with the `absent_tgt` field in
    `frame_with_absence.parquet`.
  - Off-switch: a flag such as `--wrte-reallocation` (default off until it passes the test).
  - Test: LOSO on history. It passes if chalk act-OURS on teammate-absent rows falls from +2.7 toward the ~0 FC shows,
    without hurting overall MAE.
- **QB chalk +3.6:** fold this into the pending, uncommitted QB recalibration. Check that chalk QBs are unbiased after it.
- The residual ~+1.3 on non-absence chalk is unexplained by pre-lock features we have. Label: open.
