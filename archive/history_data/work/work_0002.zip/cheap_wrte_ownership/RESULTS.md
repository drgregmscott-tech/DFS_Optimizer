﻿# Cheap WR/TE ownership: root cause (2026-09-30)

> **DO NOT COMMIT.** This file has aggregate numbers derived from FC history. The player-level outputs are in the git-ignored `data/fc_history/derived/cheap_wrte/`.

> **Baseline refresh 2026-09-30:** sections 1-2 were re-run on the current history frame (overall corr .756, not the stale .612). No verdict changes: every feature test is still within +.006 and still negative on 2026. Only the residual-correlation paragraph changed materially (the .15-.24 quality correlations were a stale-frame artifact; fresh max is .09).

**Question.** Why does our ownership under-own cheap WR/TE (under $5.5k) compared with the field? What is the field pricing in that we miss? The premise to test was role or vacated usage (who's OUT, depth changes) and Vegas environment.

## Answer

**The cheap WR/TE gap is not a role/vacated or Vegas problem.** Every rebuildable input was tested leave-one-season-out, and none of them moves cheap WR/TE by more than +.006 corr (fresh baseline). Several make 2026 worse. **Label: wrong-direction-drop** for new cheap-band features.

**On live 2026 inputs, the gap is already closed.** The ownership we ship (v2 log-blended with the live FFC model at .45) scores cheap WR/TE corr **.906 on wk3**. Wk3 is the only fair week. FC's own ownership scored .805 on history.

**The real remaining miss is not cheap-specific. It is chalk size, at every price and every position.**
- Players who end up 20%+ owned are predicted at about half their real number.
- Cheap WR/TE is simply where this shows most.
- Raw FFC gets the size of cheap chalk right: 21.6 predicted vs 18.9 real.
- Our models do not: v2 11.5, blend 12.6.

**Nothing ships from this study.** Chalk size is the next thing to test (track 2, see the end).

## 1. Where v2 misses (LOSO 2021-25, cheap WR/TE rows with real own > 0, n = 10,177)

> Refreshed 2026-09-30 against the current `hist.parquet` (rebuilt 07:48; the old `v2_loso.parquet` was built at 07:17 on the polluted frame). Output: `diag_out.txt`.

- v2 corr is .658 (was .641 stale). On 2021-23 it is .631 (was .619), against FC Own at .805.

| real own | n | real | v2 | FC Own |
|---|---|---|---|---|
| 0-2 | 7713 | 0.3 | 0.9 | 0.9 |
| 2-5 | 1235 | 3.3 | 4.0 | 3.8 |
| 5-10 | 693 | 7.1 | 5.4 | 6.1 |
| 10-20 | 417 | 13.8 | 7.5 | 8.9 |
| 20+ | 119 | 27.1 | 10.2 | 14.7 |

**The same compression shows up in every band.** For players who end up 20%+ owned:

| band | n | real | v2 | FC |
|---|---|---|---|---|
| RB/QB under $5.5k | 45 | 33.0 | 8.7 | 19.2 |
| $5.5-7k WR/TE | 108 | 26.9 | 13.5 | 16.0 |
| $7k+ WR/TE | 104 | 27.7 | 16.2 | 19.9 |

So this is not a cheap WR/TE mechanism. It is "the model can't tell which player becomes chalk", and it is worst where salaries are flat. (Fresh v2 is less compressed than the stale numbers said, but still predicts 20%+ chalk at 30-60% of real.)

**What the residual (real minus v2) tracks.** On the fresh baseline the residual has **no** sizeable pre-lock correlate: largest are FC proj .09, lag own .06, vacated .04, salary .03. (The stale run showed .15-.24 correlations with every quality input; that was an artifact of the polluted frame.) The residual correlates .11 with realized points. Conclusion unchanged: no single missing feature, a model that is too flat at the top.

**Biggest misses** (`data/fc_history/derived/cheap_wrte/top_under.csv`):
- Returns and debuts with no recent usage history: Antonio Brown 2021 wk16, Kyle Pitts and Egbuka wk1, Gronkowski's return.
- Next-man-up after an injury: Gallup, Chris Moore, Josh Palmer, McBride, Brevin Jordan, Stone Smartt.
- Many of these have a near-zero history projection. The history frame's projection is regenerated with no news, so it misses these.

## 2. What the field prices in: held-out tests (target = realized ownership)

Each row adds features to v2 linear. All inputs can be rebuilt before lock. Scripts: `test_feats.py`, `test_depth.py`, `test_news_sharpen.py`.

| added to v2 | all corr | cheap WR/TE LOSO | 2026 cheap WR/TE |
|---|---|---|---|
| baseline v2 | .756 | .658 | .799 |
| role/vacated (vacated, share, beneficiary = vacated x share, share renormalised over present teammates, cheap interactions) | .756 | .657 | .791 |
| Vegas x cheap (team total, game total) | .757 | .659 | .797 |
| role + Vegas | .756 | .654 | .792 |
| value shape in the cheap band (val, proj, val^2) | .757 | .662 | .800 |
| price lag (recent pts/salary, last value, last-week own, targets) | .757 | .661 | .800 |
| rebuilt depth (next-man-up rank among present teammates, promoted flag) | .758 | .664 | .777 |
| FC depth tag (diagnostic, FC-only) | .761 | .675 | n/a |
| FC projection as extra input (diagnostic, 2021-23 LOSO) | .756 | .602 (from .627) | n/a |
| sharpen v2 (power k = 1.1, chosen LOSO) | .750 | .650 | n/a |

(Refreshed 2026-09-30 on current `hist.parquet`; stale values were all-corr .612, cheap .641. Outputs: `test_feats_out.txt`, `test_depth_out.txt`, `test_news_sharpen_out.txt`.)

**Reading this:**
- Role/vacated and Vegas carry **no** cheap-band signal beyond what v2 already has.
- A better projection (FC's) does not help either, so this is not a projection gap.
- Global sharpening fixes chalk size a little (catch20 .41 to .45, bias20 -14.1 to -13.0) but costs rank corr.
- The rebuildable single-feature ceiling is about +.006 (FC-only depth +.017).

**What history cannot supply:**
- Pre-lock news timing, since the history pool uses "played" as its stand-in for OUT news.
- The field's crowd consensus (FFC/public ownership projections).
- Props.

FC's leftover signal correlates .74 with ours. So whatever the field acts on is information that is not in any column we can rebuild for 2021-25.

## 3. 2026 check (live inputs: news-bearing projection, real pre-lock pool, FFC)

Cheap WR/TE corr by week. v2 was trained on 2021-25 only. The live FFC artifact was fit on wk1-2, so **only wk3 is fair** for it and for the blend.

| | wk1 | wk2 | wk3 (fair) |
|---|---|---|---|
| v2 linear alone | .694 | .796 | .869 |
| live FFC artifact | .716 | .841 | .870 |
| **shipped: v2 x live FFC blend a=.45** | .731 | .870 | **.906** |
| v2 x raw FFC blend (alpha picked leave-one-week-out) | .773 | .860 | .842 |
| as-built pre-lock (old) | .437 | .601 | .870 |

**Reading this:**
- On live inputs, the shipped model is at or above FC's historical level on cheap WR/TE.
- The history gap (.64 vs .81) is mostly about what the history frame lacks, not a live defect. It tracked the same "missing info" residual.
- Blending in raw FFC instead of the fitted FFC model is not better on the fair week (.842 vs .906). Keep the shipped blend.
- **What still misses on 2026 is chalk size.** Cheap WR/TE that end up 10%+ owned average 18.9 real, against v2 11.5 and the raw-FFC blend 12.6. Raw FFC is 21.6.
- Repeat 2026 misses: Michael Mayer (x3), Devaughn Vele, Dalton Schultz, Juwan Johnson, Terry McLaurin.

## Verdict and next step

- **Cheap-band feature additions (role/vacated, Vegas, depth, price lag, value shape): wrong-direction, drop.** Tested held-out and none helps. Close the parking-lot item as "not a cheap-band mechanism".
- **Shipped v2 + FFC blend on cheap WR/TE: keep as is.** Fair-week .906 is already FC-level. Keep scoring it weekly (Wk4 is the first fully out-of-sample week).
- **Single most valuable next test (track 2, not shipped, no wiring yet): chalk size.** Every model predicts 20%+ players at about half. Raw FFC sizes chalk roughly right but ranks worse.
  - Candidate: after the existing blend in `scripts/ownership_v2.py` `refine_v2`, for players raw FFC puts in its slate top-N, pull the blended value toward raw FFC by factor b. Renormalise to group budgets.
  - Off-switch: `DFS_OWN_CHALK_FFC=0`. Write the params to a new dated file `data/ownership_v2_chalk.candidate-<date>.json`.
  - Pick b leave-one-week-out on 2026 wk1-3, then judge on Wk4-5 real ownership: catch20, bias20, MAE, top-10%.
  - It can't be tested on history, because history has no FFC. That is why this stays a test and does not ship.
- Not retried: flatter logistic scale, mid-tier multipliers, history-tuned joint layer, rank features, min-price DST flag, FFC floor a=.7.

## Files
- **Scripts** (no FC data inside):
  - `diag.py` (misses)
  - `test_feats.py` (role/Vegas/value/price-lag)
  - `test_depth.py`
  - `test_news_sharpen.py`
  - `test_ffc_blend.py` (2026)
- **Outputs:** `*_out.txt` here. Player-level files are in `data/fc_history/derived/cheap_wrte/`.
- Nothing wired, no live artifact touched, nothing committed.
